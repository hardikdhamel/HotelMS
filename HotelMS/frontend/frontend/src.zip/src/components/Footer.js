import React from 'react';
import "../styles/footer.css";

const Footer = () => {
  return (
    <footer id="footer">
      <div className="footer-container">
        <div className="footer-row">
          <div className="footer-column">
            <h5 className="footer-title">Quick Links</h5>
            <ul className="list-unstyled">
              <li><a href="https://www.hotelogix.com/careers" className="footer-link">Careers</a></li>
              <li><a href="https://www.hotelogix.com/events" className="footer-link">Events</a></li>
              <li><a href="https://www.hotelogix.com/case-studies-list" className="footer-link">Case Studies</a></li>
              <li><a href="https://www.hotelogix.com/privacy-policy" className="footer-link">Privacy Policy</a></li>
              <li><a href="https://www.hotelogix.com/terms-of-service" className="footer-link">Terms of Service</a></li>
              <li><a href="https://www.hotelogix.com/general-data-protection-regulation" className="footer-link">GDPR Compliance</a></li>
              <li><a href="https://www.hotelogix.com/partner" className="footer-link">Become a Partner</a></li>
              <li><a href="https://www.hotelogix.com/marketplace/" className="footer-link">Marketplace</a></li>
            </ul>
          </div>
          <div className="footer-column">
            <h5 className="footer-title">Features</h5>
            <ul className="list-unstyled">
              <li><a href="https://www.hotelogix.com/hotelogix-frontdesk-management-system" className="footer-link">Frontdesk</a></li>
              <li><a href="https://www.hotelogix.com/hotelogix-gds-connect" className="footer-link">GDS</a></li>
              <li><a href="https://www.hotelogix.com/hotelogix-channel-manager-details" className="footer-link">Channel Manager</a></li>
              <li><a href="https://www.hotelogix.com/reports" className="footer-link">Reports</a></li>
              <li><a href="https://www.hotelogix.com/hotelogix-distribution-system" className="footer-link">Integrated Distribution System</a></li>
            </ul>
          </div>
          <div className="footer-column">
            <h5 className="footer-title">Property Types</h5>
            <ul className="list-unstyled">
              <li><a href="https://www.hotelogix.com/hotel-management-software" className="footer-link">Hotels</a></li>
              <li><a href="https://www.hotelogix.com/resorts-management-system-software" className="footer-link">Resorts</a></li>
              <li><a href="https://www.hotelogix.com/property-types-bed-and-breakfast" className="footer-link">B&amp;B</a></li>
              <li><a href="https://www.hotelogix.com/apartments-management-system-software" className="footer-link">Serviced Apartments and Hostels</a></li>
              <li><a href="https://www.hotelogix.com/property-management-system-large-hotels-hlxe" className="footer-link">Hotel Groups</a></li>
            </ul>
          </div>
          <div className="footer-column">
            <h5 className="footer-title">Contact Us</h5>
            <ul className="list-unstyled">
              <li><strong>Sales:</strong><br />+1 530 2311 223<br /><a href="mailto:sales@hotelogix.com" className="footer-link">sales@hotelogix.com</a></li>
              <li><strong>Support:</strong><br />24x7 live support<br /><a href="mailto:support@hotelogix.com" className="footer-link">support@hotelogix.com</a></li>
            </ul>
            <div className="newsletter">
              <h6 className="footer-title">Newsletter Signup</h6>
              <form className="newsletter-form">
                <div className="input-group">
                  <input type="text" className="newsletter-input" placeholder="Enter your Email Id"/>
                  <button className="newsletter-button" type="submit">Subscribe</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div className="footer-row social-networks">
          <a href="/" className="social-link"><i className="fa fa-facebook"></i></a>
          <a href="/" className="social-link"><i className="fa fa-twitter"></i></a>
          <a href="/" className="social-link"><i className="fa fa-linkedin"></i></a>
          <a href="/" className="social-link"><i className="fa fa-youtube"></i></a>
          <a href="/" className="social-link"><i className="fa fa-pinterest"></i></a>
          <a href="/" className="social-link"><i className="fa fa-instagram"></i></a>
        </div>
        <div className="footer-bottom">
          <p>© 2024. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
