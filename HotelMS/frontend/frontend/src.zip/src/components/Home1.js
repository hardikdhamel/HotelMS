import React from 'react';
import NavBar1 from './Navbar1';
import Footer from "./Footer";
import Home from "./Home";

const Home1 = () => {
  return (
    <>
        <NavBar1 />
        <Home />
        <Footer />
    </>
  );
};

export default Home1;