import React from 'react';
import Carousel from './Carousel'; // Adjust path as needed

const Home = () => {
  const images = [
    'https://via.placeholder.com/800x400?text=Image+1',
    'https://via.placeholder.com/800x400?text=Image+2',
    'https://via.placeholder.com/800x400?text=Image+3',
    'https://via.placeholder.com/800x400?text=Image+4',
    'https://via.placeholder.com/800x400?text=Image+5',
  ];

  return (
    <div>
      <h1>Hotel Management Dashboard</h1>
      <Carousel images={images} />
      {/* Other components */}
    </div>
  );
};

export default Home;
