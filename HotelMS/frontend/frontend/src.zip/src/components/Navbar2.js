import React from 'react';
import { Link } from 'react-router-dom';

function deleteCookie(name) {
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; secure; SameSite=Lax`;
}



const Navbar2 = ({ organizationName }) => {
    return (
        <Navbar className="navbar-custom" expand="lg" sticky="top">
            <Navbar.Brand href="#">
                <img
                    src={profileIcon}
                    alt="Company Logo"
                    width="30"
                    height="30"
                    className="d-inline-block align-top"
                />
                <span className="ms-2">My Company Name</span>
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="ms-auto">
                    <span className="navbar-text me-3">{organizationName}</span>
                    {!organizationName && (
                        <Nav.Link as={Link} to="/add-organization">
                            Add Your Organization
                        </Nav.Link>
                    )}
                    <Nav.Link href="#">
                        <img
                            src={profileIcon}
                            alt="Profile Icon"
                            width="35"
                            height="35"
                            className="rounded-circle"
                        />
                    </Nav.Link>
                    <Link to="/" onClick={()=>{deleteCookie("userId")}} >
                        Sign out
                    </Link>
                </Nav>
            </Navbar.Collapse>
        </Navbar>
    );
};

export default Navbar2;
