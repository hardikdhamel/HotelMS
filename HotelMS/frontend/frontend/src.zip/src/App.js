import React, { useState } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes,Link } from 'react-router-dom';
import Home1 from './components/Home1';
import SignIn from './components/Sign_in';
import SignUp from './components/Sign_up';

const App = () => {

    return (
        <Router>
            <Routes>
               <Route path="/" element={<Home1/>} />
               <Route path="/sign_in" element={<SignIn />}></Route>
               <Route path="/sign_up" element={<SignUp />}></Route>
            </Routes>
        </Router>
    );
};

export default App;





